//
//  BRTMeetingDetailModel.m
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/21.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "BRTMeetingDetailModel.h"

@implementation BRTMeetingDetailModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.beforeMeetingImages = [[NSMutableArray alloc] init];
        self.inMeetingImages = [[NSMutableArray alloc] init];
        self.afterMeetingImages = [[NSMutableArray alloc] init];
        self.teaBreakImages = [[NSMutableArray alloc] init];
        self.carServiceImages = [[NSMutableArray alloc] init];
        self.diningImages = [[NSMutableArray alloc] init];
        self.otherImages = [[NSMutableArray alloc] init];
    }
    return self;
}

@end
