//
//  MeetingViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/13.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "BRTViewController.h"

@interface MeetingViewController : BRTViewController

@property (nonatomic, assign) BRTMeetingType meetingType;

@end
