//
//  PushNoAnimationSegue.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/20.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PushNoAnimationSegue : UIStoryboardSegue

@end
