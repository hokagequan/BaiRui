//
//  NSString+Chinese.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/2/9.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Chinese)

- (NSString*)chineseString;

@end
