//
//  BRTMeetingModel.m
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/21.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "BRTMeetingModel.h"
#import "BRTMeetingManager.h"

@implementation BRTMeetingModel

- (instancetype)init {
    self = [super init];
    if (self) {
        self.meetingDetail = [[BRTMeetingDetailModel alloc] init];
    }
    return self;
}

@end
