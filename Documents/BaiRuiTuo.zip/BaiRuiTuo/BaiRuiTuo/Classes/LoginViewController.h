//
//  LoginViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/13.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "BRTViewController.h"

@interface LoginViewController : BRTViewController

+ (void)logout;
+ (void)checkInBackgroundSuccess:(void (^)(void))success
                         failure:(void (^)(void))failure;

@end
