//
//  PushNoAnimationSegue.m
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/20.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "PushNoAnimationSegue.h"

@implementation PushNoAnimationSegue

- (void)perform{
    [[[self sourceViewController] navigationController] pushViewController:[self   destinationViewController] animated:NO];
}

@end
