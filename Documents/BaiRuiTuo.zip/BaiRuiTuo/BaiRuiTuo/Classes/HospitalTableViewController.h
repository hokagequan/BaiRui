//
//  HospitalTableViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/13.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRTViewController.h"

@interface HospitalTableViewController : BRTViewController

@property (nonatomic, assign) BRTMeetingType meetingType;

@end
