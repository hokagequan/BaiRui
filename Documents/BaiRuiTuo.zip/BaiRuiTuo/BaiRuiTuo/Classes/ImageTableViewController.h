//
//  ImageTableViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/15.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BRTMeetingManager.h"

@interface ImageTableViewController : UIViewController

@property (nonatomic, weak) NSMutableArray *images;
@property (nonatomic, assign) BRTImageType imageType;
@property (nonatomic, assign) BOOL presentsCamera;//直接拍照
@property (nonatomic, assign) BOOL hidesCameraButton;//不允许拍照

@end
