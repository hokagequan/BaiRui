//
//  UIImage+Date.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/28.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Date)

- (UIImage*)imageWithDate:(NSDate*)date;

@end
