//
//  MeetingDetailViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/14.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "BRTViewController.h"
#import "BRTMeetingDetailModel.h"

@interface MeetingDetailViewController : BRTViewController

@property (nonatomic, weak) BRTMeetingDetailModel *meetingDetail;

@end
