//
//  BRTProgressViewController.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/15.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BRTProgressViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *actIndView;
@property (weak, nonatomic) IBOutlet UILabel *tipLabel;

- (void)dismissWithMessage:(NSString*)message animated:(BOOL)animated;

@end
