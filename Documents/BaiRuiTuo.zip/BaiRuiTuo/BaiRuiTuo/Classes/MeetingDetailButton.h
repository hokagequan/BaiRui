//
//  MeetingDetailButton.h
//  BaiRuiTuo
//
//  Created by kingyee on 15/1/14.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeetingDetailButton : UIButton

@property (nonatomic, strong) UILabel *countLabel;
@property (nonatomic, strong) UIButton *cameraButton;
@property (nonatomic, assign) BOOL tapsCamera;

@end
