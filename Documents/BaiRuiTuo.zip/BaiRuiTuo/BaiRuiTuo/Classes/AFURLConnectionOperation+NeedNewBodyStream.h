//
//  AFURLConnectionOperation+NeedNewBodyStream.h
//  BaiRuiTuo
//  Fixed 'request body stream exhausted' error
//
//  Created by kingyee on 15/3/23.
//  Copyright (c) 2015年 Kingyee. All rights reserved.
//

#import "AFURLConnectionOperation.h"

@interface AFURLConnectionOperation (NeedNewBodyStream)

@end
